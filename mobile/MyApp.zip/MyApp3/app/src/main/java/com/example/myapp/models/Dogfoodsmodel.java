package com.example.myapp.models;

public class Dogfoodsmodel {

    int image;
    String name;
    String Discount;
    String type;
    String Description;

    public Dogfoodsmodel(int image, String name, String discount, String type, String description) {
        this.image = image;
        this.name = name;
        Discount = discount;
        this.type = type;
        Description = description;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDiscount() {
        return Discount;
    }

    public void setDiscount(String discount) {
        Discount = discount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}
