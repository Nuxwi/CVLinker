package com.example.myapp.models;

public class HomeVerModel {
    int image;
    String name;
    String longname;
    String price;

    public HomeVerModel(int image, String name, String longname, String price) {
        this.image = image;
        this.name = name;
        this.longname = longname;
        this.price = price;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLongname() {
        return longname;
    }

    public void setLongname(String longname) {
        this.longname = longname;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
