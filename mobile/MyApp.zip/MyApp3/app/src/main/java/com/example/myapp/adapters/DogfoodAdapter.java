package com.example.myapp.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapp.models.Dogfoodsmodel;
import com.example.myapp.models.HomeVerModel;

import java.util.List;

public class DogfoodAdapter  extends RecyclerView.Adapter<DogfoodAdapter.ViewHolder> {
    Context context;
    List<Dogfoodsmodel> list;

    public DogfoodAdapter(Context context, List<Dogfoodsmodel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public DogfoodAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull DogfoodAdapter.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}

